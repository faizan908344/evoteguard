package com.example.evoteguard

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
