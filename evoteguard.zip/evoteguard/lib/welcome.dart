import 'package:evoteguard/login.dart';
import 'package:flutter/material.dart';

class WelcomePage extends StatefulWidget {
  const WelcomePage({super.key});

  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        padding: EdgeInsets.all(30.0),
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("images/welcomebanner.jpeg"),
            fit: BoxFit.cover,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(15.0),
              width: MediaQuery.of(context).size.width,
              // height: 250,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(25.0),
                // color: Color(0x45ECECEC),
                gradient: LinearGradient(
                  colors: [
                    // Color(0xff0a0e17),
                    // Color(0xff2c3e50),
                    // Color(0xff0047ab),
                    Color(0xC8092E09), // deep forest green
                    Color(0xBE0B4D0E), // logo green (matches button)
                    Color(0xB2319731), // bright leaf green
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                border: Border.all(
                  width: 3.0,
                  color: Colors.white,
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "WELCOME TO THE E-VOTE GUARD",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 35.0,
                      fontFamily: "Cambria",
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      height: 1.2,
                    ),
                  ),
                  SizedBox(height: 15.0),
                  Text(
                    "Your Secured, Anonymous, Temper-Proof Electronic Voting System",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 20.0,
                      fontFamily: "Cambria",
                      fontWeight: FontWeight.w400,
                      color: Colors.white,
                      height: 1.2,
                    ),
                  ),
                  SizedBox(height: 18.0),
                  Row(
                    children: [
                      Icon(Icons.lock, size: 25, color: const Color(0xFFAF9607)),
                      SizedBox(width: 5.0),
                      Text(
                        "Secured, Encrypted and Private",
                        style: TextStyle(
                          fontSize: 18.0,
                          fontFamily: "Cambria",
                          fontWeight: FontWeight.w400,
                          color: Colors.white,
                          height: 1.2,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 5.0),
                  Row(
                    children: [
                      Icon(Icons.lan, size: 25, color: const Color(0xFFAF9607)),
                      SizedBox(width: 5.0),
                      Text(
                        "Decentralized, Transparent",
                        style: TextStyle(
                          fontSize: 18.0,
                          fontFamily: "Cambria",
                          fontWeight: FontWeight.w400,
                          color: Colors.white,
                          height: 1.2,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 5.0),
                  Row(
                    children: [
                      Icon(Icons.person, size: 25, color: const Color(0xFFAF9607)),
                      SizedBox(width: 5.0),
                      Text(
                        "Easy and Fast Votings",
                        style: TextStyle(
                          fontSize: 18.0,
                          fontFamily: "Cambria",
                          fontWeight: FontWeight.w400,
                          color: Colors.white,
                          height: 1.2,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20.0),
                  Container(
                    width: MediaQuery.of(context).size.width,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color(0xFF967007),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                      ),
                      onPressed: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => LoginScreen()));
                      },
                      child: Text(
                        "Get Started To Vote",
                        style: TextStyle(
                          fontSize: 17.0,
                          fontFamily: "Cambria",
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
