import 'package:flutter/material.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  // Uses the device's local time, which follows the user's country/time zone.
  String _greeting() {
    final hour = DateTime.now().hour;
    if (hour >= 5 && hour < 12) return "Good Morning";
    if (hour >= 12 && hour < 17) return "Good Afternoon";
    return "Good Evening";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF1E6B2A),
        title: const Text(
          "Dashboard",
          style: TextStyle(
            fontSize: 20,
            fontFamily: "Cambria",
            fontWeight: FontWeight.bold,
            color: Color(0xFFFFFFFF),
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                width: double.infinity,
                height: 100,
                decoration: BoxDecoration(
                  color: Color(0xFF05A51D),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      _greeting(),
                      style: const TextStyle(
                        fontSize: 15,
                        fontFamily: "Cambria",
                        color: Color(0xE6FFFFFF),
                      ),
                    ),
                    const SizedBox(height: 4),
                    const Text(
                      "Welcome Faizan",
                      style: TextStyle(
                        fontSize: 22,
                        fontFamily: "Cambria",
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ],
                ),
              )
            ]
          ),
        ),
      ),
    );
  }
}
